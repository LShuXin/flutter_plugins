#import <Flutter/Flutter.h>
#import "RecorderManager.h"
#import "PlayerManager.h"

@interface OpusRecorderPlugin : NSObject<FlutterPlugin,RecordingDelegate,PlayingDelegate>



@end
