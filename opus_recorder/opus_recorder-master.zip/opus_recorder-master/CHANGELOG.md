## 0.0.1

* TODO: Describe initial release.


## 0.0.2

* TODO: add new method for player mode
